import { motion } from 'framer-motion';

const stats = [
  {
    value: '1M+',
    label: 'Monthly Views',
    sub: 'Across all managed creators',
    icon: '◈',
  },
  {
    value: '1M+',
    label: 'Subscribers Managed',
    sub: 'Combined creator audience',
    icon: '◉',
  },
  {
    value: '15+',
    label: 'Creators',
    sub: 'Active partnerships',
    icon: '◆',
  },
];

export default function Stats() {
  return (
    <section className="py-24 relative border-t border-border/50 overflow-hidden">
      {/* Background accent */}
      <div className="absolute inset-0 bg-primary/[0.03] pointer-events-none" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <p className="font-mono text-xs text-primary/60 tracking-[0.4em] uppercase mb-3">
            // IMPACT_METRICS
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-bold">
            NUMBERS <span className="text-primary">DON'T LIE</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {stats.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
              className="relative group"
            >
              {/* Shadow offset */}
              <div className="absolute inset-0 translate-x-1.5 translate-y-1.5 bg-primary/10 border border-primary/20 transition-transform group-hover:translate-x-2.5 group-hover:translate-y-2.5" />

              <div className="relative bg-card border border-border group-hover:border-primary/60 transition-colors p-8 text-center z-10">
                {/* Top bar */}
                <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-primary/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                <div className="text-primary/30 text-2xl mb-4 group-hover:text-primary/60 transition-colors">
                  {s.icon}
                </div>

                <div
                  className="font-display text-6xl md:text-7xl font-black text-primary mb-3 group-hover:drop-shadow-[0_0_20px_rgba(139,92,246,0.6)] transition-all"
                >
                  {s.value}
                </div>

                <div className="font-mono text-sm font-bold tracking-widest text-foreground uppercase mb-2">
                  {s.label}
                </div>

                <div className="font-mono text-xs text-muted-foreground/60">
                  {s.sub}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
