import { motion } from 'framer-motion';
import { Github, ExternalLink, FolderGit2 } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: "NeX0r Bot",
    description: "A highly concurrent, distributed Discord moderation bot capable of handling 10k+ events per second. Features an embedded V8 engine for custom moderation scripts.",
    tech: ["TypeScript", "Node.js", "Redis", "Docker"],
    github: "#",
    demo: "#"
  },
  {
    id: 2,
    title: "VaultBreaker",
    description: "Penetration testing utility dashboard. Visualizes network topologies and vulnerability scans in real-time using WebGL.",
    tech: ["React", "Three.js", "Python", "WebSockets"],
    github: "#",
    demo: "#"
  },
  {
    id: 3,
    title: "ShadowAPI",
    description: "A stealthy, rate-limit bypassing proxy rotation service for massive data scraping operations. Built with Go and Rust.",
    tech: ["Go", "Rust", "PostgreSQL", "AWS"],
    github: "#",
    demo: "#"
  },
  {
    id: 4,
    title: "NullScript",
    description: "Custom minimalist code editor for terminal environments. Built entirely in bash and awk because why not.",
    tech: ["Bash", "Awk", "Linux", "Regex"],
    github: "#",
    demo: "#"
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-32 relative border-t border-border/50">
      <div className="container mx-auto px-6">
        <div className="font-mono text-sm text-primary mb-4 flex items-center gap-2">
          <span className="text-muted-foreground">03.</span> // DEPLOYMENTS
        </div>
        
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-16">
          RECENT <span className="text-primary">OPERATIONS</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: idx * 0.2 }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-primary/5 translate-x-2 translate-y-2 border border-primary/20 transition-transform group-hover:translate-x-3 group-hover:translate-y-3" />
              
              <div className="relative bg-card border border-border p-8 h-full flex flex-col hover:border-primary transition-colors z-10">
                <div className="flex justify-between items-start mb-6">
                  <FolderGit2 className="w-10 h-10 text-primary opacity-80" />
                  <div className="flex gap-4">
                    <a href={project.github} className="text-muted-foreground hover:text-primary transition-colors">
                      <Github className="w-6 h-6" />
                    </a>
                    <a href={project.demo} className="text-muted-foreground hover:text-primary transition-colors">
                      <ExternalLink className="w-6 h-6" />
                    </a>
                  </div>
                </div>

                <h3 className="font-display text-2xl font-bold mb-4 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                
                <p className="font-sans text-muted-foreground text-sm leading-relaxed mb-8 flex-grow">
                  {project.description}
                </p>

                <ul className="flex flex-wrap gap-3 font-mono text-xs">
                  {project.tech.map(tech => (
                    <li key={tech} className="text-primary bg-primary/10 px-2 py-1 rounded-sm">
                      {tech}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
