import { motion } from 'framer-motion';
import MinecraftSkin from './MinecraftSkin';

export default function About() {
  return (
    <section id="about" className="py-32 relative border-t border-border/50">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="flex-1 w-full"
          >
            <div className="font-mono text-sm text-primary mb-4 flex items-center gap-2">
              <span className="text-muted-foreground">01.</span> // WHO_AM_I
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-8">
              THE <span className="text-primary">ARCHITECT</span> OF CHAOS
            </h2>

            <div className="font-mono bg-card/50 border border-border p-6 relative overflow-hidden backdrop-blur-sm">
              <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-primary/60 to-transparent" />
              <div className="absolute top-0 left-0 w-[2px] h-full bg-gradient-to-b from-primary/60 to-transparent" />

              <div className="flex gap-2 mb-4 border-b border-border/50 pb-4">
                <div className="w-3 h-3 rounded-full bg-destructive/80" />
                <div className="w-3 h-3 rounded-full bg-accent/80" />
                <div className="w-3 h-3 rounded-full bg-primary/80" />
              </div>

              <div className="space-y-4 text-muted-foreground text-sm md:text-base leading-relaxed">
                <p>
                  <span className="text-primary">root@illegalboii:~$</span> cat identity.txt
                </p>
                <p className="pl-4 border-l border-primary/30">
                  My name is <span className="text-primary">ilLegalBoii</span>, AKA <span className="text-primary">Vivek</span>.
                  I am an <span className="text-foreground font-bold">Influencer Manager</span> — I bridge the gap between
                  creators and brands, building partnerships that actually convert.
                </p>
                <div className="pl-4 border-l border-primary/30 space-y-3">
                  <div className="flex items-start gap-3">
                    <span className="text-primary mt-0.5">▶</span>
                    <div>
                      <span className="text-foreground font-bold tracking-wider">SPONSOR MANAGEMENT</span>
                      <p className="text-muted-foreground mt-1">Connecting influencers with the right brands. Negotiating deals, managing deliverables, and making sure both sides win.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="text-primary mt-0.5">▶</span>
                    <div>
                      <span className="text-foreground font-bold tracking-wider">RECORDING MANAGEMENT</span>
                      <p className="text-muted-foreground mt-1">On-ground support for content shoots. Helping creators with video recording setups so their content hits different.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="text-primary mt-0.5">▶</span>
                    <div>
                      <span className="text-foreground font-bold tracking-wider">INFLUENCER MANAGEMENT</span>
                      <p className="text-muted-foreground mt-1">Full-scale creator management — strategy, growth, brand identity, and day-to-day operations so creators can focus on creating.</p>
                    </div>
                  </div>
                </div>
                <p>
                  <span className="text-primary">root@illegalboii:~$</span>
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ repeat: Infinity, duration: 0.7 }}
                    className="inline-block w-2 h-4 bg-primary ml-1 align-middle"
                  />
                </p>
              </div>
            </div>
          </motion.div>

          {/* Minecraft Skin 3D viewer */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex-1 relative w-full max-w-sm mx-auto"
            style={{ height: '420px' }}
          >
            {/* Outer glow border */}
            <div className="absolute -inset-[1px] bg-gradient-to-b from-primary/30 via-primary/10 to-transparent pointer-events-none" />
            <div className="absolute inset-0 bg-background/60 backdrop-blur-sm border border-primary/20">
              <MinecraftSkin />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
