import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface BootScreenProps {
  onComplete: () => void;
}

// Japanese characters for the rain
const JAPANESE_CHARS =
  'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン' +
  '日月火水木金土空海山川雨雪風雲光影暗明音夢幻剣盾炎氷雷神鬼龍' +
  'あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほ';

const BOOT_LINES = [
  'INITIALIZING QUANTUM BOOT SEQUENCE...',
  'ESTABLISHING SECURE PROTOCOLS [AES-256]... SUCCESS',
  'DECRYPTING CORE FILES (ILLEGALBOII_BIO.dat)... OK',
  'LOADING WEBGL RENDER ENGINE...',
  'MAPPING ILLEGAL NETWORK COORDINATES...',
  'CALIBRATING DARK WEB OSCILLATORS...',
  'BOOT SEQUENCE COMPLETE. WELCOME.',
];

function JapaneseRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const fontSize = 16;
    let columns = Math.floor(canvas.width / fontSize);
    const drops: number[] = Array(columns).fill(1);

    // Purple palette
    const colors = ['#7c3aed', '#8b5cf6', '#a78bfa', '#6d28d9', '#c4b5fd'];

    let animId: number;
    const draw = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < drops.length; i++) {
        const char = JAPANESE_CHARS[Math.floor(Math.random() * JAPANESE_CHARS.length)];
        const color = colors[Math.floor(Math.random() * colors.length)];

        // Brightest char at head
        if (drops[i] * fontSize < canvas.height * 0.1) {
          ctx.fillStyle = '#e9d5ff';
        } else {
          ctx.fillStyle = color;
        }

        ctx.font = `${fontSize}px monospace`;
        ctx.fillText(char, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
      animId = requestAnimationFrame(draw);
    };

    draw();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      columns = Math.floor(canvas.width / fontSize);
      drops.length = columns;
      drops.fill(1);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ opacity: 0.7 }}
    />
  );
}

export default function BootScreen({ onComplete }: BootScreenProps) {
  const [visibleLines, setVisibleLines] = useState<number>(0);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);
  const [exiting, setExiting] = useState(false);

  const locId = useRef(
    Math.random().toString(16).slice(2, 10).toUpperCase()
  ).current;

  useEffect(() => {
    // Show lines one by one
    const lineInterval = setInterval(() => {
      setVisibleLines((prev) => {
        if (prev >= BOOT_LINES.length) {
          clearInterval(lineInterval);
          return prev;
        }
        return prev + 1;
      });
    }, 600);

    return () => clearInterval(lineInterval);
  }, []);

  useEffect(() => {
    // Progress bar fills over ~4.5 seconds
    const total = 4500;
    const step = 50;
    let elapsed = 0;
    const timer = setInterval(() => {
      elapsed += step;
      const pct = Math.min(Math.round((elapsed / total) * 100), 100);
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(timer);
        setTimeout(() => setDone(true), 400);
      }
    }, step);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (done) {
      setTimeout(() => {
        setExiting(true);
        setTimeout(onComplete, 800);
      }, 300);
    }
  }, [done, onComplete]);

  return (
    <AnimatePresence>
      {!exiting && (
        <motion.div
          className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center overflow-hidden"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Japanese Rain Background */}
          <JapaneseRain />

          {/* Terminal Window */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.2 }}
            className="relative z-10 w-full max-w-xl mx-4"
          >
            {/* Corner brackets */}
            <div className="absolute -top-2 -left-2 w-5 h-5 border-t-2 border-l-2 border-purple-400" />
            <div className="absolute -top-2 -right-2 w-5 h-5 border-t-2 border-r-2 border-purple-400" />
            <div className="absolute -bottom-2 -left-2 w-5 h-5 border-b-2 border-l-2 border-purple-400" />
            <div className="absolute -bottom-2 -right-2 w-5 h-5 border-b-2 border-r-2 border-purple-400" />

            <div className="border border-purple-600/60 bg-black/80 backdrop-blur-sm px-6 py-5">
              {/* Header */}
              <div className="flex items-center justify-between mb-5 pb-3 border-b border-purple-800/50">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse shadow-[0_0_8px_rgba(167,139,250,0.9)]" />
                  <span className="font-mono text-xs text-purple-300 tracking-wider">
                    TERMINAL://CORE_BOOT_v2.0
                  </span>
                </div>
                <span className="font-mono text-xs text-purple-500/70">
                  LOC_ID: {locId}
                </span>
              </div>

              {/* Boot lines */}
              <div className="space-y-2 mb-6 min-h-[168px]">
                {BOOT_LINES.slice(0, visibleLines).map((line, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex items-start gap-2"
                  >
                    <span className="text-purple-400 font-mono text-xs mt-0.5 flex-shrink-0">&gt;</span>
                    <span
                      className={`font-mono text-xs tracking-wide ${
                        i === visibleLines - 1
                          ? 'text-purple-200'
                          : 'text-purple-400/70'
                      }`}
                    >
                      {line}
                      {i === visibleLines - 1 && progress < 100 && (
                        <motion.span
                          animate={{ opacity: [1, 0] }}
                          transition={{ repeat: Infinity, duration: 0.6 }}
                          className="inline-block w-2 h-3 bg-purple-400 ml-1 align-middle"
                        />
                      )}
                    </span>
                  </motion.div>
                ))}
              </div>

              {/* Progress */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-mono text-xs text-purple-500">
                    SYSTEM INTEGRATION STATUS
                  </span>
                  <span className="font-mono text-xs text-purple-300">
                    {progress}%
                  </span>
                </div>
                <div className="h-1.5 bg-purple-950 w-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-purple-700 via-violet-500 to-fuchsia-400"
                    style={{ width: `${progress}%` }}
                    transition={{ duration: 0.05 }}
                  />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Press nothing text */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.5, 0] }}
            transition={{ repeat: Infinity, duration: 2.5, delay: 0.8 }}
            className="relative z-10 mt-6 font-mono text-xs text-purple-600 tracking-[0.3em]"
          >
            PRESS NOTHING // GRID STABILIZING
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
