import { motion } from 'framer-motion';
import { Mail } from 'lucide-react';

function DiscordIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
    </svg>
  );
}

function InstagramIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

export default function Contact() {
  return (
    <section id="contact" className="py-32 relative border-t border-border/50">
      <div className="container mx-auto px-6 max-w-4xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="font-mono text-sm text-primary mb-4 flex items-center justify-center gap-2">
            <span className="text-muted-foreground">04.</span> // SECURE_COMM
          </div>

          <h2 className="font-display text-4xl md:text-6xl font-bold mb-8">
            INITIATE <span className="text-primary">CONTACT</span>
          </h2>

          <p className="font-mono text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
            My inbox is open for new operations. Whether you have a question or just want to say hi, I'll try my best to get back to you. No guarantees though — I might be mid-deployment.
          </p>

          <a
            href="mailto:viveklokesh123124@gmail.com"
            className="inline-flex items-center gap-3 px-8 py-4 bg-primary/10 border border-primary text-primary font-mono uppercase tracking-widest hover:bg-primary hover:text-background transition-all hover:shadow-[0_0_20px_rgba(139,92,246,0.5)] group"
          >
            <Mail className="w-5 h-5 group-hover:animate-pulse" />
            Send_Transmission
          </a>

          <div className="mt-20 flex justify-center gap-12">
            {/* Instagram */}
            <a
              href="https://www.instagram.com/the_illegalboii/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-2 text-muted-foreground hover:text-primary transition-colors group"
            >
              <div className="p-4 border border-border group-hover:border-primary bg-card transition-colors group-hover:shadow-[0_0_16px_rgba(139,92,246,0.3)]">
                <InstagramIcon className="w-6 h-6" />
              </div>
              <span className="font-mono text-xs tracking-wider">The_illegalboii</span>
            </a>

            {/* Discord */}
            <a
              href="https://discord.com/users/illegalboii"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-2 text-muted-foreground hover:text-accent transition-colors group"
            >
              <div className="p-4 border border-border group-hover:border-accent bg-card transition-colors group-hover:shadow-[0_0_16px_rgba(192,38,211,0.3)]">
                <DiscordIcon className="w-6 h-6" />
              </div>
              <span className="font-mono text-xs tracking-wider">illegalboii</span>
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
