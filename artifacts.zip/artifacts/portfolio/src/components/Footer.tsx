export default function Footer() {
  return (
    <footer className="py-8 border-t border-border bg-background">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="font-mono text-xs text-muted-foreground flex items-center gap-2">
          <span className="text-primary">root@system:</span> ~$ exit
        </div>
        <div className="font-mono text-xs text-muted-foreground">
          Built by <span className="text-primary hover:text-accent transition-colors cursor-pointer">ilLegalBoii</span> © {new Date().getFullYear()}
        </div>
        <div className="font-mono text-xs text-muted-foreground flex gap-4">
          <span>V_1.0.0</span>
          <span className="animate-pulse text-primary">SYS_OK</span>
        </div>
      </div>
    </footer>
  );
}
