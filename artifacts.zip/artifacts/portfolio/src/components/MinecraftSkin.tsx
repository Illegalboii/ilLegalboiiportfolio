import { useEffect, useRef, useState } from 'react';
import minecraftSkinUrl from '@/assets/minecraft-skin.png';

/* ─── 2D pixelated fallback ───────────────────────────────────────────────── */
function drawSkin2D(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  W: number,
  H: number,
) {
  ctx.clearRect(0, 0, W, H);
  ctx.imageSmoothingEnabled = false;
  const scale = Math.min(W / 16, H / 32) * 0.85;
  const ox = (W - 16 * scale) / 2;
  const oy = (H - 32 * scale) / 2;
  const blit = (sx: number, sy: number, sw: number, sh: number,
                dx: number, dy: number, dw: number, dh: number) =>
    ctx.drawImage(img, sx, sy, sw, sh, ox + dx * scale, oy + dy * scale, dw * scale, dh * scale);
  blit(8, 8, 8, 8, 4, 0, 8, 8);
  blit(40, 8, 8, 8, 4, 0, 8, 8);
  blit(20, 20, 8, 12, 4, 8, 8, 12);
  blit(44, 20, 4, 12, 0, 8, 4, 12);
  ctx.save(); ctx.translate(ox + 16 * scale, oy + 8 * scale); ctx.scale(-1, 1);
  ctx.drawImage(img, 44, 20, 4, 12, 0, 0, 4 * scale, 12 * scale); ctx.restore();
  blit(4, 20, 4, 12, 4, 20, 4, 12);
  ctx.save(); ctx.translate(ox + 12 * scale, oy + 20 * scale); ctx.scale(-1, 1);
  ctx.drawImage(img, 4, 20, 4, 12, 0, 0, 4 * scale, 12 * scale); ctx.restore();
}

/* ─── 3D loader with smooth lerped cursor tracking ───────────────────────── */
async function tryLoad3D(canvas: HTMLCanvasElement, onDispose: (fn: () => void) => void) {
  try {
    const { SkinViewer } = await import('skinview3d');

    const viewer = new SkinViewer({
      canvas,
      width: canvas.offsetWidth || 280,
      height: canvas.offsetHeight || 420,
      skin: minecraftSkinUrl,
    });

    viewer.renderer.setClearColor(0x000000, 0);
    viewer.camera.position.z = 70;
    viewer.fov = 50;
    // keep skinview3d's own render loop alive — just update rotations via RAF

    // target & current rotation values (lerped each frame)
    const target = { bodyY: 0, headY: 0, headX: 0 };
    const current = { bodyY: 0, headY: 0, headX: 0 };

    const onMouseMove = (e: MouseEvent) => {
      const nx = (e.clientX / window.innerWidth - 0.5) * 2;   // -1 … +1
      const ny = (e.clientY / window.innerHeight - 0.5) * 2;  // -1 … +1
      target.bodyY = nx * 0.7;
      target.headY = nx * 0.9;
      target.headX = -ny * 0.5;
    };

    window.addEventListener('mousemove', onMouseMove);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const obj = viewer.playerObject as any;

    let rafId = 0;
    const LERP = 0.08;
    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

    const tick = () => {
      rafId = requestAnimationFrame(tick);
      current.bodyY = lerp(current.bodyY, target.bodyY, LERP);
      current.headY = lerp(current.headY, target.headY, LERP);
      current.headX = lerp(current.headX, target.headX, LERP);

      // rotate whole body
      viewer.playerObject.rotation.y = current.bodyY;

      // rotate head independently (try both possible API paths)
      const head = obj?.skin?.head ?? obj?.playerSkin?.head ?? obj?.head;
      if (head) {
        head.rotation.y = current.headY - current.bodyY;
        head.rotation.x = current.headX;
      }
      // skinview3d renders on its own — no manual render call needed
    };
    tick();

    onDispose(() => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('mousemove', onMouseMove);
      viewer.dispose();
    });
    return true;
  } catch {
    return false;
  }
}

/* ─── Component ───────────────────────────────────────────────────────────── */
export default function MinecraftSkin() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<'loading' | '3d' | '2d'>('loading');

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let disposed = false;
    let disposeFn: (() => void) | null = null;

    tryLoad3D(canvas, (fn) => { disposeFn = fn; }).then((ok) => {
      if (disposed) return;
      if (ok) {
        setMode('3d');
      } else {
        setMode('2d');
        const img = new Image();
        img.onload = () => {
          if (disposed || !canvas) return;
          const ctx = canvas.getContext('2d');
          if (ctx) drawSkin2D(ctx, img, canvas.width, canvas.height);
        };
        img.src = minecraftSkinUrl;
      }
    });

    return () => {
      disposed = true;
      disposeFn?.();
    };
  }, []);

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Purple glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-36 h-56 rounded-full bg-primary/15 blur-[50px]" />
      </div>

      <canvas
        ref={canvasRef}
        width={280}
        height={420}
        className="w-full h-full"
        style={{ imageRendering: mode === '2d' ? 'pixelated' : 'auto' }}
      />

      {/* Corner brackets */}
      <div className="absolute top-2 left-2 w-5 h-5 border-t-2 border-l-2 border-primary/60 pointer-events-none" />
      <div className="absolute top-2 right-2 w-5 h-5 border-t-2 border-r-2 border-primary/60 pointer-events-none" />
      <div className="absolute bottom-2 left-2 w-5 h-5 border-b-2 border-l-2 border-primary/60 pointer-events-none" />
      <div className="absolute bottom-2 right-2 w-5 h-5 border-b-2 border-r-2 border-primary/60 pointer-events-none" />

      <div className="absolute bottom-4 left-0 right-0 text-center pointer-events-none">
        <span className="font-mono text-[10px] text-primary/50 tracking-widest">
          ENTITY_MODEL // ilLegalBoii
        </span>
      </div>

      {mode === '3d' && (
        <div className="absolute top-4 left-0 right-0 text-center pointer-events-none">
          <span className="font-mono text-[9px] text-primary/30 tracking-widest animate-pulse">
            ◈ CURSOR_TRACKED
          </span>
        </div>
      )}
    </div>
  );
}
