import { useEffect, useRef } from 'react';

const JAPANESE_CHARS =
  'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン' +
  '日月火水木金土空海山川雨雪風雲光影暗明音夢幻剣盾炎氷雷神鬼龍' +
  'あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほ';

interface JapaneseRainBgProps {
  opacity?: number;
  fontSize?: number;
}

export default function JapaneseRainBg({ opacity = 0.18, fontSize = 14 }: JapaneseRainBgProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const setSize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    setSize();

    let cols = Math.floor(canvas.width / fontSize);
    const drops: number[] = Array(cols).fill(1);

    const purples = ['#6d28d9', '#7c3aed', '#8b5cf6', '#a78bfa', '#5b21b6'];

    let animId: number;
    const draw = () => {
      ctx.fillStyle = 'rgba(0,0,0,0.06)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < drops.length; i++) {
        const char = JAPANESE_CHARS[Math.floor(Math.random() * JAPANESE_CHARS.length)];
        const yPos = drops[i] * fontSize;

        // Bright head
        if (drops[i] < 3) {
          ctx.fillStyle = '#ddd6fe';
        } else {
          ctx.fillStyle = purples[Math.floor(Math.random() * purples.length)];
        }

        ctx.font = `${fontSize}px monospace`;
        ctx.fillText(char, i * fontSize, yPos);

        if (yPos > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }

      animId = requestAnimationFrame(draw);
    };

    draw();

    const onResize = () => {
      setSize();
      cols = Math.floor(canvas.width / fontSize);
      drops.length = cols;
      for (let i = 0; i < cols; i++) if (drops[i] === undefined) drops[i] = 1;
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', onResize);
    };
  }, [fontSize]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none"
      style={{ opacity, zIndex: 0 }}
    />
  );
}
