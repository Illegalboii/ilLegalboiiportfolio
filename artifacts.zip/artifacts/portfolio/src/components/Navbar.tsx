import { useEffect, useState } from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';
import { Terminal, ShieldAlert } from 'lucide-react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const navLinks = [
    { name: '// ABOUT', id: 'about' },
    { name: '// SKILLS', id: 'skills' },
    { name: '// SECURE_COMM', id: 'contact' },
  ];

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-primary/20 ${
          scrolled ? 'bg-background/90 backdrop-blur-md py-3' : 'bg-transparent py-5'
        }`}
      >
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div
            className="flex items-center gap-2 cursor-pointer group"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <Terminal className="w-6 h-6 text-primary group-hover:text-accent transition-colors" />
            <span className="font-display font-bold text-xl tracking-wider">
              ilLegal<span className="text-primary group-hover:text-accent transition-colors">Boii</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="text-sm font-mono text-muted-foreground hover:text-primary transition-colors px-2 py-1 relative group hover:shadow-[0_0_10px_rgba(139,92,246,0.4)]"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
              </button>
            ))}
          </div>

          <div className="md:hidden">
            <ShieldAlert className="text-primary w-6 h-6" />
          </div>
        </div>

        {/* Purple scroll progress bar */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-[1px] bg-primary origin-left shadow-[0_0_6px_rgba(139,92,246,0.8)]"
          style={{ scaleX }}
        />
      </motion.nav>
    </>
  );
}
