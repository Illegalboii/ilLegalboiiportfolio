import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { useEffect, useState } from 'react';

const creators = [
  { name: 'InsaneRMK',      url: 'https://www.youtube.com/@InsaneRMK' },
  { name: 'InsaneMayank',   url: 'https://www.youtube.com/@InsaneMayankOG' },
  { name: 'HaiderPlayz',    url: 'https://www.youtube.com/@HaiderPlayz786' },
  { name: 'MrOverated',     url: 'https://www.youtube.com/@Mr_OverratedXD' },
  { name: 'EagleHawkEyeYt', url: 'https://www.youtube.com/@eaglehawkeyegaming' },
  { name: 'TeenPlayz',       url: 'https://www.youtube.com/@TeenPlayz' },
  { name: 'Bulky Star',      url: 'https://www.youtube.com/@BulkyStar' },
  { name: 'NexBisht',        url: 'https://www.youtube.com/@NexBisht' },
  { name: 'DimensionThunder',url: 'https://www.youtube.com/@DimoThunderz' },
  { name: 'UgPlayz',         url: 'https://www.youtube.com/@UGPlayzZ_OG' },
  { name: 'MrOnish',         url: 'https://www.youtube.com/@MrOnishOfficial' },
  { name: 'DRAGIII',         url: 'https://www.youtube.com/@dragiiibankai' },
  { name: 'Mayank Gaming',   url: 'https://www.youtube.com/@madapgaming.' },
  { name: 'Byfun',           url: 'https://www.youtube.com/@BYFUNOP' },
  { name: 'BeingStrang',     url: 'https://www.youtube.com/@USeeStrang' },
];

export default function Hero() {
  const [text, setText] = useState('');
  const fullText = "SYSTEM BREACHED... ACCESS GRANTED.";

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      if (i < fullText.length) {
        setText((prev) => prev + fullText.charAt(i));
        i++;
      } else {
        clearInterval(timer);
      }
    }, 80);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="min-h-[100dvh] flex flex-col relative pt-20">
      {/* Purple background orbs */}
      <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-accent/8 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/2 w-48 h-48 bg-primary/6 rounded-full blur-[80px] pointer-events-none" />

      {/* ── Main content — grows to fill available space ── */}
      <div className="flex-1 flex items-center relative z-10">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl"
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="w-3 h-3 bg-primary rounded-full animate-pulse shadow-[0_0_12px_rgba(139,92,246,0.9)]" />
              <span className="font-mono text-primary/80 text-sm tracking-widest">STATUS: ONLINE</span>
            </div>

            <h1
              className="font-display text-5xl md:text-8xl font-black uppercase tracking-tighter mb-4 text-foreground glitch"
              data-text="ilLegalBoii"
            >
              ilLegal<span className="text-primary">Boii</span>
            </h1>

            <div className="h-8 mb-6 flex items-center">
              <p className="font-mono text-lg md:text-xl text-muted-foreground">
                {text}
                <motion.span
                  animate={{ opacity: [1, 0] }}
                  transition={{ repeat: Infinity, duration: 0.8 }}
                  className="inline-block w-3 h-5 bg-primary ml-1 align-middle"
                />
              </p>
            </div>

            {/* Highlighted Gmail */}
            <a
              href="mailto:viveklokesh123124@gmail.com"
              className="inline-flex items-center gap-2 mb-8 font-mono text-sm group"
            >
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_8px_rgba(139,92,246,0.9)]" />
              <span className="text-muted-foreground group-hover:text-primary transition-colors duration-300">
                viveklokesh123124@gmail.com
              </span>
              <span className="px-2 py-0.5 border border-primary/50 text-primary text-xs tracking-widest group-hover:bg-primary group-hover:text-background transition-all duration-300">
                CONTACT
              </span>
            </a>

            <div className="flex flex-col sm:flex-row gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 bg-primary/10 border border-primary text-primary font-mono uppercase tracking-widest hover:bg-primary hover:text-background transition-all hover:shadow-[0_0_24px_rgba(139,92,246,0.5)]"
              >
                View_Profile.sh
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 border border-border text-foreground font-mono uppercase tracking-widest hover:border-accent hover:text-accent transition-all hover:shadow-[0_0_24px_rgba(192,38,211,0.3)]"
              >
                Initialize_Contact
              </motion.button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* ── Trusted by strip — pinned to bottom, full width ── */}
      <div className="relative z-10 pb-12">
        <p className="font-mono text-xs text-muted-foreground/40 tracking-[0.3em] text-center uppercase mb-3">
          Best Influencer Marketing Manager — Trusted By
        </p>

        <div className="flex overflow-hidden border-y border-primary/15 py-3 bg-background/30 backdrop-blur-sm">
          <motion.div
            animate={{ x: ['0%', '-50%'] }}
            transition={{ repeat: Infinity, duration: 20, ease: 'linear' }}
            className="flex shrink-0"
          >
            {[...creators, ...creators].map((c, i) => (
              <a
                key={i}
                href={c.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-8 font-mono text-sm text-muted-foreground hover:text-primary transition-colors group whitespace-nowrap"
              >
                <span className="text-primary/30 group-hover:text-primary transition-colors text-xs">▶</span>
                <span className="group-hover:underline underline-offset-4 decoration-primary/50">{c.name}</span>
              </a>
            ))}
          </motion.div>
        </div>

        {/* Scroll arrow */}
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="flex flex-col items-center mt-4 cursor-pointer text-muted-foreground hover:text-primary transition-colors"
          onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
        >
          <div className="font-mono text-[10px] mb-1 opacity-40 tracking-widest">SCROLL</div>
          <ChevronDown className="w-5 h-5" />
        </motion.div>
      </div>
    </section>
  );
}
