import { motion } from 'framer-motion';

const skillsData = [
  { category: 'FRONTEND', items: ['React', 'TypeScript', 'Tailwind', 'Next.js', 'Framer Motion'] },
  { category: 'BACKEND', items: ['Node.js', 'Python', 'PostgreSQL', 'Redis', 'GraphQL'] },
  { category: 'SYSTEMS', items: ['Linux', 'Docker', 'AWS', 'Git', 'Bash'] },
  { category: 'EXPLOITS', items: ['WebSockets', 'WebRTC', 'Three.js', 'WebGL', 'WASM'] },
];

export default function Skills() {
  return (
    <section id="skills" className="py-32 relative border-t border-border/50 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="font-mono text-sm text-primary mb-4 flex items-center gap-2">
          <span className="text-muted-foreground">02.</span> // ARSENAL
        </div>
        
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-16">
          TECHNICAL <span className="text-primary">LOADOUT</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillsData.map((group, idx) => (
            <motion.div
              key={group.category}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="bg-card/30 border border-border p-6 hover:border-primary/50 transition-colors group relative"
            >
              <div className="absolute top-0 right-0 p-2 opacity-20 font-mono text-xs">
                [{idx + 1}]
              </div>
              <h3 className="font-mono font-bold text-lg mb-6 text-foreground border-b border-border/50 pb-2 group-hover:text-primary transition-colors">
                {group.category}
              </h3>
              <ul className="space-y-4">
                {group.items.map((skill, sIdx) => (
                  <li key={skill} className="flex items-center gap-3 font-mono text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                    <span className="text-primary/50 text-xs">▶</span>
                    {skill}
                    <motion.div 
                      className="h-[1px] bg-primary/20 flex-1 ml-2"
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8, delay: 0.3 + (sIdx * 0.1) }}
                      style={{ originX: 0 }}
                    />
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Decorative Grid */}
        <div className="mt-20 border border-border/30 p-4 font-mono text-xs text-muted-foreground/50 hidden md:block">
          <div className="flex justify-between border-b border-border/30 pb-2 mb-2">
            <span>MEMORY_DUMP</span>
            <span>0x00FF99</span>
          </div>
          <div className="grid grid-cols-8 gap-4 overflow-hidden h-24">
            {Array.from({ length: 32 }).map((_, i) => (
              <span key={i} className="hover:text-primary transition-colors cursor-crosshair">
                {Math.random().toString(16).substr(2, 4).toUpperCase()}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
