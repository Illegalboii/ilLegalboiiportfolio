import { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

const VIDEO_ID = 'EAbq3Du4Oss'; // Nevada City – Huma Huma (YouTube Audio Library)

export default function MusicPlayer() {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [muted, setMuted] = useState(false);
  const [ready, setReady] = useState(false);
  const playerRef = useRef<any>(null);

  useEffect(() => {
    // Load YouTube IFrame API
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);

    (window as any).onYouTubeIframeAPIReady = () => {
      playerRef.current = new (window as any).YT.Player('yt-music-player', {
        videoId: VIDEO_ID,
        playerVars: {
          autoplay: 1,
          loop: 1,
          playlist: VIDEO_ID,
          controls: 0,
          disablekb: 1,
          fs: 0,
          iv_load_policy: 3,
          modestbranding: 1,
          rel: 0,
        },
        events: {
          onReady: (e: any) => {
            e.target.setVolume(40);
            e.target.playVideo();
            setReady(true);
          },
        },
      });
    };

    return () => {
      delete (window as any).onYouTubeIframeAPIReady;
    };
  }, []);

  const toggleMute = () => {
    const p = playerRef.current;
    if (!p) return;
    if (muted) {
      p.unMute();
      p.setVolume(40);
    } else {
      p.mute();
    }
    setMuted(!muted);
  };

  return (
    <>
      {/* Hidden YouTube iframe */}
      <div className="fixed -top-[9999px] -left-[9999px] w-px h-px overflow-hidden pointer-events-none" aria-hidden>
        <div id="yt-music-player" ref={iframeRef as any} />
      </div>

      {/* Floating mute/unmute button */}
      {ready && (
        <button
          onClick={toggleMute}
          title={muted ? 'Unmute music' : 'Mute music'}
          className="fixed bottom-6 right-6 z-[100] flex items-center gap-2 px-3 py-2 bg-background/80 border border-primary/40 text-primary backdrop-blur-md hover:bg-primary/10 hover:border-primary transition-all group shadow-[0_0_12px_rgba(139,92,246,0.25)]"
        >
          {muted ? (
            <VolumeX className="w-4 h-4" />
          ) : (
            <Volume2 className="w-4 h-4 animate-pulse" />
          )}
          <span className="font-mono text-[10px] tracking-widest hidden sm:block">
            {muted ? 'MUTED' : 'NEVADA CITY'}
          </span>
        </button>
      )}
    </>
  );
}
