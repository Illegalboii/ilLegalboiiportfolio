export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground relative">
      <div className="scanlines"></div>
      <div className="text-center font-mono relative z-10">
        <h1 className="text-8xl font-display font-bold text-primary mb-4 glitch" data-text="404">404</h1>
        <p className="text-xl mb-8 text-muted-foreground">DIRECTORY_NOT_FOUND</p>
        <a href="/" className="px-6 py-3 border border-primary text-primary hover:bg-primary hover:text-background transition-colors uppercase tracking-widest inline-block">
          Return_To_Root
        </a>
      </div>
    </div>
  );
}
