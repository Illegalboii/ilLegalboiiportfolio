import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import About from '../components/About';
import Skills from '../components/Skills';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import JapaneseRainBg from '../components/JapaneseRainBg';
import MusicPlayer from '../components/MusicPlayer';
import Stats from '../components/Stats';

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground relative selection:bg-primary/30 selection:text-primary">
      {/* Japanese purple rain — fixed, behind everything */}
      <JapaneseRainBg opacity={0.15} fontSize={14} />

      {/* Scanlines overlay */}
      <div className="scanlines" />

      <Navbar />
      <main className="relative z-10">
        <Hero />
        <About />
        <Skills />
        <Stats />
        <Contact />
      </main>
      <MusicPlayer />
      <Footer />
    </div>
  );
}
